import time

import numpy as np
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import JointState


class HyperParamRunner(Node):
    def __init__(self):
        super().__init__('hyperparam_runner')

        self.joint_state_pub = self.create_publisher(
            JointState,
            '/ves/left/joint/servo_jp',
            1
        )

        self.joint_state_sub = self.create_subscription(
            JointState,
            '/ves/left/joint/filtered/measured_jp',
            self.joint_state_callback,
            10
        )

        self.joint_state = None

    def joint_state_callback(self, msg):
        self.joint_state = np.array(msg.position[:4], dtype=float)

    def send_cmd_joint_state(self, q):
        cmd = JointState()
        cmd.header.stamp = self.get_clock().now().to_msg()
        cmd.name = ['ir', 'or', 'it', 'ot', 'tool']
        cmd.position = [float(q[0]), float(q[1]), float(q[2]), float(q[3]), 0.0]
        self.joint_state_pub.publish(cmd)

    def sample_waypoint(self, q_prev):
        # outer rot goes in a v shape, away from pi, since it will hit the camera
        outer_rot = np.random.uniform(-2 / 3 * np.pi, 2 / 3 * np.pi)

        # outer pos has full range of actuation
        outer_pos = np.random.uniform(0.0, 0.02)

        # inner rot can be anything, but only changes by at most 30 degrees from previous to avoid large jumps
        inner_rot = q_prev[0] + np.random.uniform(-np.radians(30), np.radians(30))

        # Ensure inner position is always greater than outer, and that it is at least 0.015 to avoid checkerboard/robot collision
        inner_pos_low = max(outer_pos, 0.015)
        inner_pos = np.random.uniform(inner_pos_low, 0.04)

        return np.array([inner_rot, outer_rot, inner_pos, outer_pos], dtype=float)
    
    def run(self, num_waypoints=1000, time_per_waypoint=15.0):
        # Wait until we have received at least one joint state
        while rclpy.ok() and self.joint_state is None:
            self.get_logger().info("Waiting for initial joint state...")
            rclpy.spin_once(self, timeout_sec=1.0)
        
        # Start from current position for smoother motion
        q_prev = self.joint_state.copy()

        for i in range(num_waypoints):
            self.get_logger().info(f"Moving to waypoint {i+1}/{num_waypoints}")

            q_next = self.sample_waypoint(q_prev)
            t_start = self.get_clock().now()

            while rclpy.ok(): 
                elapsed = self.get_clock().now() - t_start
                dt = elapsed.nanoseconds * 1e-9
                if dt > time_per_waypoint:
                    break

                # Interpolate cmd position between q_prev and q_next
                alpha = dt / time_per_waypoint
                q_cmd = (1 - alpha) * q_prev + alpha * q_next
                self.send_cmd_joint_state(q_cmd)

                time.sleep(0.01)

            q_prev = q_next

        self.get_logger().info("Completed all waypoints.")


def main():
    rclpy.init()
    node = HyperParamRunner()

    try:
        node.run()
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
