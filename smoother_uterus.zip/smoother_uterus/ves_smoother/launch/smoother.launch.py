import os

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, OpaqueFunction
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory

def is_true(value):
    return value.lower() in ('1', 'true', 'yes', 'y', 't')

def generate_launch_description():

    run_dir = DeclareLaunchArgument(
        'run_dir',
        default_value='',
        description='The directory to save the run logs'
    )

    load_calib = DeclareLaunchArgument(
        'load',
        default_value='0',
        description='load:=1 Load smoother calibration file (default: 0)'
    )

    # Define a flag to determine whether to launch visual_servoing node
    run_visual_servo_server = DeclareLaunchArgument(
        'run_visual_servo_server',
        default_value='true',
        description='Whether to launch visual_servoing nodes'
    )

    run_rviz = DeclareLaunchArgument(
        'run_rviz',
        default_value='true',
        description='Whether to launch RViz display',
    )

    left_tool_length_arg = DeclareLaunchArgument(
        'left_tool_length',
        default_value='0.004',
        description='left tool (tip) length in meters, default is spatula (0.004)'
    )

    right_tool_length_arg = DeclareLaunchArgument(
        'right_tool_length',
        default_value='0.008',
        description='right tool (tip) length in meters, default is electrosurgery (0.008)'
    )

    return LaunchDescription([
        load_calib,
        run_visual_servo_server,
        run_rviz,
        run_dir,
        left_tool_length_arg,
        right_tool_length_arg,
        OpaqueFunction(function=launch_setup),
    ])

def launch_setup(context, *args, **kwargs):
    
    nodes = []

    load_calib = is_true(LaunchConfiguration('load').perform(context))
    run_visual_servo = is_true(LaunchConfiguration('run_visual_servo_server').perform(context))
    run_rviz = is_true(LaunchConfiguration('run_rviz').perform(context))
    run_dir = LaunchConfiguration('run_dir').perform(context)

    left_tool_length = float(LaunchConfiguration('left_tool_length').perform(context))
    right_tool_length = float(LaunchConfiguration('right_tool_length').perform(context))

    # Create ves_smoother node with the smoother config.yaml file
    nodes.append(Node(
        package='ves_smoother',
        executable='ves_smoother',
        name='ves_smoother',
        output='screen',
        parameters=[
            {
                'load': load_calib,
                'run_dir': run_dir,
                'left.tip_offset.z': left_tool_length,
                'right.tip_offset.z': right_tool_length
            },
        ],
    ))

    if run_visual_servo:
        nodes.append(Node(
            package='visual_servoing',
            executable='action_server',
            name='action_server',
            output='screen',
            prefix='taskset -c 0'  # TODO figure out how to not do it this way
        ))
    if run_rviz:
        pkg_share = get_package_share_directory('ves_smoother')
        rviz_config_file = os.path.join(pkg_share, 'config', 'smoother.rviz')
        nodes.append(Node(
            package='rviz2',
            executable='rviz2',
            name='rviz2',
            output='screen',
            arguments=['-d', rviz_config_file],
        ))


    return nodes
